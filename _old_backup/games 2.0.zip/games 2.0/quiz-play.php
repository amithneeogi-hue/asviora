<?php
/**
 * Quiz contest — the round itself.
 *
 * The page ships no answers. It asks api/quiz.php for one question at a
 * time and only learns which option was correct after it has submitted a
 * choice, so the answer key cannot be read out of the page source.
 */
require_once __DIR__ . '/config/config.php';

require_login('quiz.php');

if (!quiz_on()) {
    flash('The quiz contest is not available right now.', 'info');
    redirect('quiz.php');
}

$u        = current_user();
$uid      = (int) $u['id'];
$levelKey = get('level');
$levels   = quiz_levels();
if (!isset($levels[$levelKey])) {
    $levelKey = 'easy';
}
$level    = $levels[$levelKey];
$catId    = (int) get('cat');
$perRound = quiz_round_size();

// -------------------------------------------------------------------
// Drop any round the player walked away from
// -------------------------------------------------------------------
q('UPDATE quiz_sessions SET status = "abandoned"
    WHERE user_id = ? AND status = "active"', [$uid]);

// -------------------------------------------------------------------
// Pick the questions
// -------------------------------------------------------------------
$sql    = 'SELECT id FROM quiz_questions WHERE is_active = 1 AND difficulty = ?';
$params = [$levelKey];
if ($catId) {
    $sql .= ' AND category_id = ?';
    $params[] = $catId;
}
$sql .= ' ORDER BY RAND() LIMIT ' . (int) $perRound;

$ids = array_map('intval', array_column(fetch_all($sql, $params), 'id'));

if (!$ids) {
    flash('No questions are available for that level yet.', 'info');
    redirect('quiz.php');
}

// -------------------------------------------------------------------
// Coins are paid for the first N finished rounds each day
// -------------------------------------------------------------------
$dailyCap  = (int) setting('quiz_daily_rounds', '5');
$playedToday = (int) fetch_col(
    'SELECT COUNT(*) FROM quiz_sessions
      WHERE user_id = ? AND status = "finished" AND DATE(finished_at) = CURDATE()',
    [$uid], 0
);
$paid = ($dailyCap <= 0) || ($playedToday < $dailyCap);

$sid = insert_row('quiz_sessions', [
    'user_id'     => $uid,
    'category_id' => $catId ?: null,
    'difficulty'  => $levelKey,
    'total'       => count($ids),
    'payload'     => json_encode(['ids' => $ids, 'res' => [], 'paid' => $paid]),
    'status'      => 'active',
]);

$page_title = ucfirst($levelKey) . ' Quiz';
$page_desc  = 'A timed quiz round on Aegis Esports.';
$extra_head = '<meta name="robots" content="noindex">';
require __DIR__ . '/includes/header.php';
?>

<section class="section">
  <div class="container">
    <div class="quiz-shell" id="quizShell"
         data-endpoint="<?= url('api/quiz.php') ?>"
         data-session="<?= (int) $sid ?>"
         data-csrf="<?= csrf_token() ?>"
         data-total="<?= count($ids) ?>"
         data-lobby="<?= url('quiz.php') ?>"
         data-again="<?= url('quiz-play.php?level=' . e($levelKey) . ($catId ? '&cat=' . $catId : '')) ?>">

      <div class="quiz-bar">
        <div>
          <span class="badge badge-<?= $levelKey === 'hard' ? 'gold' : ($levelKey === 'mid' ? 'info' : 'green') ?>">
            <?= $level['icon'] ?> <?= e($level['label']) ?>
          </span>
          <span class="qb-step" id="qbStep">Question 1 / <?= count($ids) ?></span>
        </div>

        <div class="row" style="align-items:center;gap:14px;margin:0">
          <span class="coin-pill nowrap">&#129689; <span id="qbCoins">0</span> earned</span>
          <div class="timer-ring" id="timerRing">
            <svg viewBox="0 0 62 62">
              <circle class="tr-track" cx="31" cy="31" r="27"></circle>
              <circle class="tr-bar" id="trBar" cx="31" cy="31" r="27"
                      stroke-dasharray="169.6" stroke-dashoffset="0"></circle>
            </svg>
            <div class="tr-num" id="trNum"><?= (int) $level['seconds'] ?></div>
          </div>
        </div>
      </div>

      <div class="quiz-progress" id="quizProgress">
        <?php for ($i = 0; $i < count($ids); $i++): ?><i></i><?php endfor; ?>
      </div>

      <?php if (!$paid): ?>
        <div class="alert alert-info" data-persist="1"><span>&#8505;</span>
          You have already claimed your <?= (int) $dailyCap ?> rewarded rounds today.
          This round still counts for your stats, but pays no coins.
        </div>
      <?php endif; ?>

      <!-- everything inside .noselect is copy-protected -->
      <div class="card q-card noselect" id="qCard">
        <div class="center" style="padding:40px 0">
          <div style="font-size:2.2rem">&#129504;</div>
          <p class="text-muted" style="margin:10px 0 0">Loading your first question&hellip;</p>
        </div>
      </div>

      <div class="row between mt-3">
        <a href="<?= url('quiz.php') ?>" class="btn btn-ghost btn-sm"
           data-confirm="Leave the round? Your progress will not be saved.">Quit round</a>
        <button class="btn btn-primary btn-sm" id="nextBtn" hidden>Next question &rarr;</button>
      </div>

    </div>
  </div>
</section>

<script>
(function () {
  'use strict';

  var shell = document.getElementById('quizShell');
  if (!shell) return;

  var ENDPOINT = shell.dataset.endpoint,
      SESSION  = shell.dataset.session,
      CSRF     = shell.dataset.csrf,
      TOTAL    = parseInt(shell.dataset.total, 10);

  var qCard   = document.getElementById('qCard'),
      qbStep  = document.getElementById('qbStep'),
      qbCoins = document.getElementById('qbCoins'),
      ring    = document.getElementById('timerRing'),
      trBar   = document.getElementById('trBar'),
      trNum   = document.getElementById('trNum'),
      nextBtn = document.getElementById('nextBtn'),
      pips    = document.getElementById('quizProgress').children;

  var CIRC = 2 * Math.PI * 27;
  trBar.setAttribute('stroke-dasharray', CIRC.toFixed(1));

  var timer = null, left = 0, span = 0, locked = false, earned = 0, current = 0;

  /* ================================================================
     COPY PROTECTION
     Question and answer text must not be copyable, right-clickable,
     draggable, printable or scrapable through the usual shortcuts.
     ================================================================ */
  function guard(ev) { ev.preventDefault(); return false; }

  ['contextmenu', 'copy', 'cut', 'paste', 'selectstart', 'dragstart']
    .forEach(function (type) {
      document.addEventListener(type, function (ev) {
        if (ev.target.closest && ev.target.closest('input, textarea')) return;
        return guard(ev);
      }, { capture: true });
    });

  document.addEventListener('keydown', function (ev) {
    var k = (ev.key || '').toLowerCase();

    // devtools + view-source + save + print + select-all + copy
    if (k === 'f12') return guard(ev);
    if (ev.ctrlKey && ev.shiftKey && ['i', 'j', 'c', 'k'].indexOf(k) > -1) return guard(ev);
    if ((ev.ctrlKey || ev.metaKey) && ['u', 's', 'p', 'a', 'c', 'x'].indexOf(k) > -1) {
      if (ev.target.closest && ev.target.closest('input, textarea')) return;
      return guard(ev);
    }

    // keyboard answering: 1-4 or A-D
    if (!locked && current) {
      var n = 0;
      if (k >= '1' && k <= '4') n = parseInt(k, 10);
      if (k >= 'a' && k <= 'd') n = k.charCodeAt(0) - 96;
      if (n) {
        var btn = qCard.querySelector('.opt[data-choice="' + n + '"]');
        if (btn) btn.click();
      }
    }
  }, { capture: true });

  // clearing the selection defeats select-then-drag copying
  document.addEventListener('mouseup', function () {
    if (window.getSelection) {
      var s = window.getSelection();
      if (s.rangeCount && !document.activeElement.matches('input, textarea')) {
        var node = s.anchorNode;
        if (node && node.parentElement && node.parentElement.closest('.noselect')) {
          s.removeAllRanges();
        }
      }
    }
  });

  /* ---------------- transport ---------------- */
  function call(action, extra) {
    var body = { action: action, session: SESSION, csrf: CSRF };
    for (var k in extra) body[k] = extra[k];

    return fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (r) { return r.json(); });
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ---------------- countdown ---------------- */
  function stopTimer() { if (timer) { clearInterval(timer); timer = null; } }

  function startTimer(seconds) {
    stopTimer();
    span = seconds; left = seconds;
    paint();
    timer = setInterval(function () {
      left--;
      paint();
      if (left <= 0) { stopTimer(); submit(0); }
    }, 1000);
  }

  function paint() {
    trNum.textContent = Math.max(0, left);
    var frac = span > 0 ? (span - left) / span : 1;
    trBar.style.strokeDashoffset = (CIRC * frac).toFixed(1);
    ring.classList.toggle('warn',   left <= Math.ceil(span * 0.4) && left > Math.ceil(span * 0.2));
    ring.classList.toggle('danger', left <= Math.ceil(span * 0.2));
  }

  /* ---------------- render ---------------- */
  var KEYS = ['A', 'B', 'C', 'D'];

  function loadQuestion() {
    locked = false;
    nextBtn.hidden = true;

    call('question').then(function (r) {
      if (!r.ok) { fail(r.message); return; }
      if (r.retry) { loadQuestion(); return; }
      if (r.done)  { finish(); return; }

      current = r.index;
      qbStep.textContent = 'Question ' + r.index + ' / ' + r.total;

      for (var i = 0; i < pips.length; i++) pips[i].classList.remove('now');
      if (pips[r.index - 1]) pips[r.index - 1].classList.add('now');

      var html = '';
      if (r.image) html += '<img class="q-image" src="' + esc(r.image) + '" alt="">';
      html += '<div class="q-text">' + esc(r.question) + '</div><div class="opt-list">';
      r.options.forEach(function (opt, i) {
        html += '<button type="button" class="opt" data-choice="' + (i + 1) + '">' +
                  '<span class="opt-key">' + KEYS[i] + '</span>' +
                  '<span class="opt-txt">' + esc(opt) + '</span>' +
                '</button>';
      });
      html += '</div>';
      qCard.innerHTML = html;

      Array.prototype.forEach.call(qCard.querySelectorAll('.opt'), function (b) {
        b.addEventListener('click', function () {
          if (locked) return;
          submit(parseInt(b.dataset.choice, 10));
        });
      });

      startTimer(r.seconds);
    }).catch(function () { fail('Connection lost. Check your network.'); });
  }

  function submit(choice) {
    if (locked) return;
    locked = true;
    stopTimer();

    Array.prototype.forEach.call(qCard.querySelectorAll('.opt'), function (b) {
      b.disabled = true;
    });

    call('answer', { choice: choice }).then(function (r) {
      if (!r.ok) { fail(r.message); return; }

      var chosen = qCard.querySelector('.opt[data-choice="' + choice + '"]');
      var right  = qCard.querySelector('.opt[data-choice="' + r.answer + '"]');
      if (right) right.classList.add('is-right');
      if (chosen && !r.correct) chosen.classList.add('is-wrong');

      var pip = pips[current - 1];
      if (pip) { pip.classList.remove('now'); pip.classList.add(r.correct ? 'ok' : 'bad'); }

      if (r.coins) {
        earned += r.coins;
        qbCoins.textContent = earned;
        if (window.asvioraToast) window.asvioraToast('+' + r.coins + ' coins', 'success');
      } else if (r.expired) {
        if (window.asvioraToast) window.asvioraToast('Time up on that one', 'error');
      }

      if (r.explanation) {
        var box = document.createElement('div');
        box.className = 'q-explain';
        box.innerHTML = '<b>' + (r.correct ? 'Correct.' : 'Answer:') + '</b> ' + esc(r.explanation);
        qCard.appendChild(box);
      }

      nextBtn.hidden = false;
      nextBtn.textContent = r.done ? 'See my result →' : 'Next question →';
      nextBtn.onclick = function () { r.done ? finish() : loadQuestion(); };

    }).catch(function () { fail('Connection lost while sending your answer.'); });
  }

  /* ---------------- result ---------------- */
  function finish() {
    stopTimer();
    nextBtn.hidden = true;

    call('finish').then(function (r) {
      if (!r.ok) { fail(r.message); return; }
      var s = r.summary;

      var verdict = s.percent === 100 ? 'Flawless round.'
                  : s.percent >= 70  ? 'Strong round.'
                  : s.percent >= 40  ? 'Solid, but there is room.'
                  : 'Rough one. Run it back.';

      var html =
        '<div class="quiz-result">' +
          '<div class="qr-score">' + s.correct + '/' + s.total + '</div>' +
          '<p class="qr-sub">' + verdict + ' You scored ' + s.percent + '%.</p>' +
          '<div class="qr-stats">' +
            '<div class="qs"><b class="text-green">' + s.correct + '</b><span>Correct</span></div>' +
            '<div class="qs"><b style="color:var(--danger)">' + s.wrong + '</b><span>Missed</span></div>' +
            '<div class="qs"><b class="text-gold">' + s.coins + '</b><span>Coins</span></div>' +
            '<div class="qs"><b>' + s.xp + '</b><span>XP</span></div>' +
          '</div>' +
          (s.bonus ? '<div class="alert alert-success" data-persist="1"><span>&#127881;</span>' +
                     'Perfect round bonus: +' + s.bonus + ' coins</div>' : '') +
          (s.paid === false ? '<p class="text-dim">Daily reward limit reached &mdash; ' +
                     'this round was scored but not paid.</p>' : '') +
          '<div class="row" style="justify-content:center;margin-top:8px">' +
            '<a class="btn btn-primary" href="' + shell.dataset.again + '">Play again</a>' +
            '<a class="btn btn-ghost" href="' + shell.dataset.lobby + '">Back to quiz lobby</a>' +
          '</div>' +
        '</div>';

      qCard.classList.remove('noselect');
      qCard.innerHTML = html;
      qCard.scrollIntoView({ behavior: 'smooth', block: 'center' });

    }).catch(function () { fail('Could not save your result.'); });
  }

  function fail(msg) {
    stopTimer();
    qCard.classList.remove('noselect');
    qCard.innerHTML =
      '<div class="empty"><div class="em-ico">&#9888;</div>' +
      '<h3>Round interrupted</h3><p>' + esc(msg || 'Something went wrong.') + '</p>' +
      '<a class="btn btn-primary" href="' + shell.dataset.lobby + '">Back to the lobby</a></div>';
  }

  // a round left half-played is closed out server-side on the next start,
  // but tell the server anyway if the tab goes away
  window.addEventListener('pagehide', function () {
    if (navigator.sendBeacon && !locked) {
      navigator.sendBeacon(ENDPOINT, new Blob(
        [JSON.stringify({ action: 'finish', session: SESSION, csrf: CSRF })],
        { type: 'application/json' }
      ));
    }
  });

  loadQuestion();
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>

<?php
/**
 * Quiz engine API.
 *
 * Everything that matters is decided here, on the server:
 *  - the question order,
 *  - which option is correct,
 *  - whether the answer arrived inside the time limit,
 *  - how many coins were earned.
 *
 * The browser is only ever sent the question text and the four options.
 * The correct answer is released *after* the player has committed to one.
 *
 * Actions:  question | answer | finish
 */
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');

/** Send JSON and stop. */
function out(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    out(['ok' => false, 'message' => 'POST only.'], 405);
}
if (!is_logged_in()) {
    out(['ok' => false, 'message' => 'Please log in again.', 'redirect' => url('login.php')], 401);
}
if (!quiz_on()) {
    out(['ok' => false, 'message' => 'The quiz is not available right now.'], 403);
}

$body = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($body)) {
    $body = $_POST;
}

if (!isset($body['csrf'], $_SESSION['csrf'])
    || !hash_equals($_SESSION['csrf'], (string) $body['csrf'])) {
    out(['ok' => false, 'message' => 'Session expired. Reload the page.'], 419);
}

$user   = current_user();
$uid    = (int) $user['id'];
$action = (string) ($body['action'] ?? '');
$sid    = (int) ($body['session'] ?? 0);

$sess = fetch_one('SELECT * FROM quiz_sessions WHERE id = ? AND user_id = ?', [$sid, $uid]);
if (!$sess) {
    out(['ok' => false, 'message' => 'Round not found.'], 404);
}

$payload = json_decode((string) $sess['payload'], true);
if (!is_array($payload) || empty($payload['ids'])) {
    out(['ok' => false, 'message' => 'Round data is corrupt. Start a new round.'], 422);
}

$ids   = $payload['ids'];
$res   = $payload['res'] ?? [];
$level = quiz_level($sess['difficulty']);
$total = count($ids);
$idx   = count($res);            // 0-based index of the question now in play

/** Persist the payload back onto the session row. */
function save_payload(int $sid, array $payload): void
{
    q('UPDATE quiz_sessions SET payload = ? WHERE id = ?', [json_encode($payload), $sid]);
}

/** Build the summary a finished round returns. */
function summarise(array $sess, int $total): array
{
    $correct = (int) $sess['correct'];
    $pct     = $total > 0 ? round($correct / $total * 100) : 0;
    return [
        'correct' => $correct,
        'wrong'   => (int) $sess['answered'] - $correct,
        'total'   => $total,
        'percent' => $pct,
        'coins'   => (int) $sess['coins_earned'],
        'xp'      => (int) $sess['xp_earned'],
        'time'    => (int) $sess['time_taken'],
    ];
}

// -------------------------------------------------------------------
// Already finished? Only `finish` makes sense.
// -------------------------------------------------------------------
if ($sess['status'] !== 'active' && $action !== 'finish') {
    out(['ok' => false, 'message' => 'This round is already over.', 'done' => true]);
}

switch ($action) {

// -------------------------------------------------------------------
// Serve the next question (never includes the correct answer)
// -------------------------------------------------------------------
case 'question':

    if ($idx >= $total) {
        out(['ok' => true, 'done' => true, 'summary' => summarise($sess, $total)]);
    }

    $qid = (int) $ids[$idx];
    $row = fetch_one('SELECT id, question, option_a, option_b, option_c, option_d, image
                        FROM quiz_questions WHERE id = ?', [$qid]);
    if (!$row) {
        // question was deleted mid-round — skip it cleanly
        $res[] = ['q' => $qid, 'choice' => 0, 'ok' => false, 'sec' => 0, 'skipped' => true];
        $payload['res'] = $res;
        save_payload($sid, $payload);
        out(['ok' => true, 'retry' => true]);
    }

    // stamp the serve time — this is what the answer is measured against
    $payload['served'] = time();
    save_payload($sid, $payload);

    $options = array_values(array_filter([
        $row['option_a'], $row['option_b'], $row['option_c'], $row['option_d'],
    ], static fn($o) => $o !== null && $o !== ''));

    out([
        'ok'       => true,
        'index'    => $idx + 1,
        'total'    => $total,
        'seconds'  => (int) $level['seconds'],
        'question' => $row['question'],
        'image'    => $row['image'] ? UPLOAD_URL . '/quiz/' . rawurlencode($row['image']) : null,
        'options'  => $options,
    ]);

// -------------------------------------------------------------------
// Grade an answer
// -------------------------------------------------------------------
case 'answer':

    if ($idx >= $total) {
        out(['ok' => true, 'done' => true, 'summary' => summarise($sess, $total)]);
    }

    $qid    = (int) $ids[$idx];
    $choice = (int) ($body['choice'] ?? 0);          // 0 = ran out of time
    $choice = ($choice >= 1 && $choice <= 4) ? $choice : 0;

    $row = fetch_one('SELECT * FROM quiz_questions WHERE id = ?', [$qid]);
    if (!$row) {
        out(['ok' => false, 'message' => 'Question no longer exists.'], 410);
    }

    // ---- server-side clock ----
    // 2 extra seconds of slack for the round-trip; anything later is a timeout.
    $served  = (int) ($payload['served'] ?? time());
    $elapsed = max(0, time() - $served);
    $limit   = (int) $level['seconds'];
    $expired = $elapsed > $limit + 2;

    if ($expired) {
        $choice = 0;
    }

    $isRight = ($choice > 0 && $choice === (int) $row['correct']);

    // ---- reward ----
    // Coins are only paid for the first N rounds of the day; after that the
    // quiz still runs (and still scores) but stops paying out.
    $coins = 0;
    if ($isRight && !empty($payload['paid'])) {
        $coins = (int) $level['reward'];
    }

    $res[] = [
        'q'      => $qid,
        'choice' => $choice,
        'ok'     => $isRight,
        'sec'    => min($elapsed, $limit),
        'coins'  => $coins,
    ];
    $payload['res'] = $res;
    unset($payload['served']);
    save_payload($sid, $payload);

    q('UPDATE quiz_questions SET times_asked = times_asked + 1,
                                 times_right = times_right + ?
        WHERE id = ?', [$isRight ? 1 : 0, $qid]);

    q('UPDATE quiz_sessions
          SET answered = answered + 1,
              correct  = correct + ?,
              coins_earned = coins_earned + ?,
              xp_earned    = xp_earned + ?,
              time_taken   = time_taken + ?
        WHERE id = ?',
      [$isRight ? 1 : 0, $coins, $isRight ? (int) $level['xp'] : 0,
       min($elapsed, $limit), $sid]);

    if ($coins > 0) {
        add_coins($uid, $coins, 'quiz',
                  ucfirst($sess['difficulty']) . ' quiz — correct answer');
    }
    if ($isRight) {
        add_xp($uid, (int) $level['xp']);
    }

    $done = count($res) >= $total;

    out([
        'ok'          => true,
        'correct'     => $isRight,
        'expired'     => $expired,
        'answer'      => (int) $row['correct'],
        'explanation' => $row['explanation'],
        'coins'       => $coins,
        'done'        => $done,
    ]);

// -------------------------------------------------------------------
// Close the round out and pay the perfect-round bonus
// -------------------------------------------------------------------
case 'finish':

    if ($sess['status'] === 'finished') {
        out(['ok' => true, 'summary' => summarise($sess, $total)]);
    }

    $correct = (int) $sess['correct'];
    $bonus   = 0;

    if (!empty($payload['paid']) && $total > 0 && $correct === $total) {
        $bonus = (int) setting('quiz_perfect_bonus', '100');
        if ($bonus > 0) {
            add_coins($uid, $bonus, 'quiz',
                      'Perfect ' . $sess['difficulty'] . ' round — all ' . $total . ' correct');
        }
    }

    q('UPDATE quiz_sessions
          SET status = "finished", finished_at = NOW(), coins_earned = coins_earned + ?
        WHERE id = ?', [$bonus, $sid]);

    $sess = fetch_one('SELECT * FROM quiz_sessions WHERE id = ?', [$sid]);

    $summary          = summarise($sess, $total);
    $summary['bonus'] = $bonus;
    $summary['paid']  = !empty($payload['paid']);
    $summary['balance'] = (int) fetch_col('SELECT coins FROM users WHERE id = ?', [$uid], 0);

    out(['ok' => true, 'summary' => $summary]);

default:
    out(['ok' => false, 'message' => 'Unknown action.'], 400);
}

<?php
/**
 * Daily spin wheel — one free spin per player per day.
 */
require_once __DIR__ . '/config/config.php';

$u        = current_user();
$enabled  = spin_on();
$segments = spin_segments();
$todayRow = $u ? spin_today((int) $u['id']) : null;

$recent = $myHistory = [];
$totalWon = 0;

if ($enabled) {
    // recent winners, for a bit of social proof
    $recent = fetch_all(
        'SELECT s.coins, s.created_at, u.username, u.avatar, u.name
           FROM spin_results s JOIN users u ON u.id = s.user_id
          ORDER BY s.id DESC LIMIT 8'
    );

    if ($u) {
        $myHistory = fetch_all(
            'SELECT spin_date, coins FROM spin_results
              WHERE user_id = ? ORDER BY spin_date DESC LIMIT 7',
            [(int) $u['id']]
        );
        $totalWon = (int) fetch_col(
            'SELECT COALESCE(SUM(coins),0) FROM spin_results WHERE user_id = ?',
            [(int) $u['id']], 0
        );
    }
}

$page_title = 'Daily Spin';
$page_desc  = 'One free spin every day. Up to 1,000 coins, no entry fee, no catch.';
require __DIR__ . '/includes/header.php';

$n = count($segments);
?>

<section class="page-hero">
  <div class="container">
    <div class="crumb"><a href="<?= url('index.php') ?>">Home</a> &rsaquo; Daily Spin</div>
    <h1>Daily <span class="gradient-text">Spin</span></h1>
    <p>One free spin every day. The wheel resets at midnight &mdash; miss a day and it is gone.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <?= render_flash() ?>

    <?php if (!$enabled): ?>
      <div class="card empty">
        <div class="em-ico">&#127920;</div>
        <h3>The wheel is resting</h3>
        <p>The daily spin is switched off or not installed yet. Check back soon.</p>
        <a class="btn btn-primary" href="<?= url('games.php') ?>">Play a game instead</a>
      </div>

    <?php elseif (!$segments): ?>
      <div class="card empty">
        <div class="em-ico">&#9881;</div>
        <h3>Wheel not configured</h3>
        <p>An administrator still needs to set the prize segments.</p>
      </div>

    <?php else: ?>
      <div class="spin-wrap">

        <div class="spin-stage" id="spinStage"
             data-endpoint="<?= url('api/spin.php') ?>"
             data-csrf="<?= csrf_token() ?>"
             data-count="<?= $n ?>"
             data-spun="<?= $todayRow ? 1 : 0 ?>">

          <div class="wheel-holder">
            <div class="wheel-pointer"></div>

            <?php
            // Build the wheel as an SVG pie: segment i occupies the slice
            // centred on angle (i * 360/n), measured clockwise from the top.
            $step = 360 / $n;
            $R    = 100;
            ?>
            <svg class="wheel" id="wheel" viewBox="-105 -105 210 210" aria-label="Prize wheel">
              <circle cx="0" cy="0" r="103" fill="none"
                      stroke="rgba(34,211,238,.45)" stroke-width="3"></circle>
              <?php foreach ($segments as $i => $s):
                  $a0 = deg2rad($i * $step - $step / 2 - 90);
                  $a1 = deg2rad($i * $step + $step / 2 - 90);
                  $x0 = round($R * cos($a0), 3); $y0 = round($R * sin($a0), 3);
                  $x1 = round($R * cos($a1), 3); $y1 = round($R * sin($a1), 3);
                  $largeArc = $step > 180 ? 1 : 0;
                  // label sits mid-slice, two-thirds out
                  $am = deg2rad($i * $step - 90);
                  $lx = round($R * 0.66 * cos($am), 3);
                  $ly = round($R * 0.66 * sin($am), 3);
                  $rot = $i * $step;
              ?>
              <path d="M 0 0 L <?= $x0 ?> <?= $y0 ?> A <?= $R ?> <?= $R ?> 0 <?= $largeArc ?> 1 <?= $x1 ?> <?= $y1 ?> Z"
                    fill="<?= e($s['color']) ?>" stroke="rgba(8,10,18,.65)" stroke-width="1"></path>
              <text x="<?= $lx ?>" y="<?= $ly ?>"
                    transform="rotate(<?= $rot ?> <?= $lx ?> <?= $ly ?>)"
                    text-anchor="middle" dominant-baseline="middle"
                    fill="#ffffff" font-size="12" font-weight="800"
                    style="paint-order:stroke;stroke:rgba(0,0,0,.45);stroke-width:2.5px">
                <?= (int) $s['coins'] ?>
              </text>
              <?php endforeach; ?>
            </svg>

            <div class="wheel-hub"><div class="logo-crest"></div></div>
          </div>

          <div class="center mt-3" style="position:relative;z-index:5">
            <?php if (!$u): ?>
              <a class="btn btn-primary btn-lg" href="<?= url('login.php') ?>">Log in to spin</a>
              <p class="text-dim mt-2" style="margin-bottom:0">Free account, free spin, every day.</p>

            <?php elseif ($todayRow): ?>
              <button class="btn btn-primary btn-lg is-disabled" id="spinBtn" disabled>
                Already spun today
              </button>
              <p class="text-muted mt-2" style="margin-bottom:0">
                You won <strong class="text-gold"><?= num($todayRow['coins']) ?> coins</strong> today.
                Next spin in <span class="countdown-next" id="nextIn"
                  data-seconds="<?= seconds_to_midnight() ?>">&hellip;</span>
              </p>

            <?php else: ?>
              <button class="btn btn-primary btn-lg" id="spinBtn">&#127920; Spin the wheel</button>
              <p class="text-dim mt-2" style="margin-bottom:0">Free &mdash; costs you nothing.</p>
            <?php endif; ?>
          </div>

          <div class="spin-win" id="spinWin">
            <div>
              <div style="font-size:2.4rem">&#127881;</div>
              <div class="sw-amt" id="swAmt">0</div>
              <p class="text-muted">coins added to your wallet</p>
              <button class="btn btn-ghost btn-sm" id="swClose">Nice</button>
            </div>
          </div>
        </div>

        <div>
          <div class="card mb-3">
            <h3 style="font-size:1.05rem">Prize table</h3>
            <ul class="spin-prizes">
              <?php foreach ($segments as $s): ?>
                <li>
                  <span class="sp-dot" style="background:<?= e($s['color']) ?>"></span>
                  <span class="text-muted"><?= num($s['coins']) ?> coins</span>
                  <span class="sp-amt"><?= round($s['weight'] / max(1, array_sum(array_column($segments, 'weight'))) * 100) ?>%</span>
                </li>
              <?php endforeach; ?>
            </ul>
            <p class="form-hint" style="margin-top:14px">
              Odds are shown as a percentage chance per spin.
            </p>
          </div>

          <?php if ($u): ?>
            <div class="card mb-3">
              <h3 style="font-size:1.05rem">Your spins</h3>
              <div class="kv"><span class="k">Total won</span>
                <span class="v text-gold"><?= num($totalWon) ?> coins</span></div>
              <?php foreach ($myHistory as $h): ?>
                <div class="kv">
                  <span class="k"><?= fdate($h['spin_date']) ?></span>
                  <span class="v">+<?= num($h['coins']) ?></span>
                </div>
              <?php endforeach; ?>
              <?php if (!$myHistory): ?>
                <p class="text-dim" style="margin:10px 0 0">No spins yet. The first one is waiting.</p>
              <?php endif; ?>
            </div>
          <?php endif; ?>

          <?php if ($recent): ?>
            <div class="card">
              <h3 style="font-size:1.05rem">Just won</h3>
              <?php foreach ($recent as $r): ?>
                <div class="u-cell" style="padding:8px 0">
                  <img src="<?= e(avatar_url($r)) ?>" alt="">
                  <div style="min-width:0">
                    <div class="u-name"><?= e($r['username']) ?></div>
                    <div class="u-sub"><?= fdate($r['created_at'], 'd M') ?></div>
                  </div>
                  <span class="sp-amt" style="margin-left:auto">+<?= num($r['coins']) ?></span>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="section-sm">
  <div class="container">
    <div class="cta-band">
      <h2>Turn those coins into a score</h2>
      <p class="text-muted">Take your spin winnings into the quiz contest or the games.</p>
      <div class="row" style="justify-content:center;margin-top:18px">
        <a class="btn btn-primary" href="<?= url('quiz.php') ?>">&#129504; Quiz contest</a>
        <a class="btn btn-ghost" href="<?= url('games.php') ?>">&#127918; All games</a>
      </div>
    </div>
  </div>
</section>

<script>
(function () {
  'use strict';

  var stage = document.getElementById('spinStage');
  if (!stage) return;

  var wheel = document.getElementById('wheel'),
      btn   = document.getElementById('spinBtn'),
      win   = document.getElementById('spinWin'),
      swAmt = document.getElementById('swAmt'),
      swX   = document.getElementById('swClose'),
      N     = parseInt(stage.dataset.count, 10),
      STEP  = 360 / N,
      busy  = false,
      turns = 0;

  /* ---- countdown to the next spin ---- */
  var next = document.getElementById('nextIn');
  if (next) {
    var left = parseInt(next.dataset.seconds, 10) || 0;
    (function tick() {
      if (left <= 0) { next.textContent = 'a moment — refresh'; return; }
      var h = Math.floor(left / 3600),
          m = Math.floor((left % 3600) / 60),
          s = left % 60;
      next.textContent = h + 'h ' + ('0' + m).slice(-2) + 'm ' + ('0' + s).slice(-2) + 's';
      left--;
      setTimeout(tick, 1000);
    })();
  }

  if (swX) swX.addEventListener('click', function () { win.classList.remove('show'); });

  if (!btn || btn.disabled) return;

  btn.addEventListener('click', function () {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    btn.textContent = 'Spinning…';
    wheel.classList.add('is-spinning');

    fetch(stage.dataset.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csrf: stage.dataset.csrf })
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {

        if (!res.ok && res.redirect) { window.location = res.redirect; return; }

        if (!res.ok && !res.already) {
          wheel.classList.remove('is-spinning');
          btn.disabled = false;
          btn.textContent = '🎰 Spin the wheel';
          busy = false;
          if (window.asvioraToast) window.asvioraToast(res.message || 'Spin failed.', 'error');
          return;
        }

        // land the pointer (top of the wheel) on the winning slice
        var seg    = res.segment || 0,
            target = 360 - (seg * STEP);
        turns += 6;                                   // six full rotations of drama
        wheel.style.transform = 'rotate(' + (turns * 360 + target) + 'deg)';

        setTimeout(function () {
          if (res.already) {
            btn.textContent = 'Already spun today';
            if (window.asvioraToast) window.asvioraToast(res.message, 'error');
            return;
          }
          swAmt.textContent = res.coins.toLocaleString('en-IN');
          win.classList.add('show');
          btn.textContent = 'Come back tomorrow';

          var pill = document.querySelector('.nav-cta .coin-pill');
          if (pill) pill.innerHTML = '🪙 ' + res.balance.toLocaleString('en-IN');
        }, 5500);
      })
      .catch(function () {
        wheel.classList.remove('is-spinning');
        btn.disabled = false;
        btn.textContent = '🎰 Spin the wheel';
        busy = false;
        if (window.asvioraToast) window.asvioraToast('Network error. Try again.', 'error');
      });
  });
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>

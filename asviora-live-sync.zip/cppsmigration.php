<?php
/**
 * ===================================================================
 * CPPS MIGRATION  —  Asviora Games schema v6   (standalone)
 * ===================================================================
 * Ekdom eka cholte pare — site-er kono file include kore na, sudhu
 * config/config.php theke DB credentials ta pore ney. Tai site-er onno
 * kono file bhangleo ei page ta cholbe ar bolbe kothay ki attke ache.
 *
 *      https://asviora.in/cppsmigration.php?key=cpps-2026
 *
 * Ei migration ta ki kore:
 *
 *   1. VISITOR ANALYTICS  — `visits`, `ip_geo`, `visit_daily` table
 *      toiri kore. Kon din, kon desh / rajya / sohor theke koto visitor
 *      elo — sob admin panel-e dekha jabe.
 *
 *   2. SPIN LIMIT         — `spin_access` table-e cooldown_minutes,
 *      weekly_cap, monthly_cap column add kore. Admin -> Daily Spin
 *      theke per-day limit, cooldown ar weekly/monthly cap set kora jabe.
 *
 *   3. GOVT EXAM          — `exam_notify` table + module row, coming-soon
 *      section ar tar interest list-er jonno.
 *
 *   4. Notun settings row gulo INSERT IGNORE kore, ar schema_version
 *      6-e tule dey.
 *
 * Sob statement idempotent — dubar chalale kichu nosto hoy na.
 *
 * KAJ SESH HOLE EI FILE TA SERVER THEKE DELETE KORE DEBEN.
 * ===================================================================
 */

@ini_set('display_errors', '1');
@ini_set('display_startup_errors', '1');
@set_time_limit(300);
error_reporting(E_ALL);

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        echo '<pre style="white-space:pre-wrap;background:#2a0f14;color:#ff9b97;border:1px solid #7a2b2b;'
           . 'padding:16px;border-radius:12px;font:13px/1.6 monospace;margin:18px">'
           . 'FATAL: ' . htmlspecialchars($e['message']) . "\n"
           . 'File : ' . htmlspecialchars($e['file']) . ':' . (int) $e['line']
           . '</pre>';
    }
});

/* ---------- key ---------- */
$MIGRATION_KEY = 'cpps-2026';
$TARGET_VERSION = 6;

$ROOT  = __DIR__;
$keyOk = isset($_GET['key']) && hash_equals($MIGRATION_KEY, (string) $_GET['key']);
$run   = $keyOk && isset($_GET['run']) && $_GET['run'] === '1';

/* ===================================================================
 * Server diagnostics
 * =================================================================== */
$diag = array(
    'PHP version'         => PHP_VERSION,
    'PDO MySQL'           => extension_loaded('pdo_mysql') ? 'ache' : 'NEI — host support lagbe',
    'cURL (geo lookup)'   => function_exists('curl_init') ? 'ache'
                             : (ini_get('allow_url_fopen') ? 'nei, kintu allow_url_fopen ache'
                                                           : 'NEI — city/country lookup cholbe na'),
    'mbstring'            => function_exists('mb_substr') ? 'ache' : 'NEI — lagbe',
    'Site folder'         => $ROOT,
);

/* ===================================================================
 * config/config.php theke DB credentials ber kora
 * =================================================================== */
function cpps_creds($file)
{
    if (!is_file($file)) {
        return array();
    }
    $src = file_get_contents($file);
    if ($src === false) {
        return array();
    }

    preg_match_all(
        "/define\\(\\s*'(DB_HOST|DB_NAME|DB_USER|DB_PASS)'\\s*,\\s*'([^']*)'\\s*\\)/",
        $src, $m, PREG_SET_ORDER);

    $sets = array();
    $cur  = array();
    foreach ($m as $one) {
        if ($one[1] === 'DB_HOST' && $cur) {
            $sets[] = $cur;
            $cur = array();
        }
        $cur[$one[1]] = $one[2];
    }
    if ($cur) {
        $sets[] = $cur;
    }

    // live server hole live block ta age try korbo
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower($_SERVER['HTTP_HOST']) : '';
    $isLocal = ($host === 'localhost' || strpos($host, 'localhost:') === 0
             || strpos($host, '127.0.0.1') === 0 || strpos($host, '192.168.') === 0);
    if (!$isLocal) {
        $sets = array_reverse($sets);
    }
    return $sets;
}

function cpps_connect($sets, &$why)
{
    $why = array();
    foreach ($sets as $s) {
        if (!isset($s['DB_NAME'])) {
            continue;
        }
        $host = isset($s['DB_HOST']) ? $s['DB_HOST'] : 'localhost';
        $user = isset($s['DB_USER']) ? $s['DB_USER'] : 'root';
        $pass = isset($s['DB_PASS']) ? $s['DB_PASS'] : '';
        try {
            $pdo = new PDO('mysql:host=' . $host . ';dbname=' . $s['DB_NAME'] . ';charset=utf8mb4',
                           $user, $pass,
                           array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                                 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC));
            $why[] = $s['DB_NAME'] . ' @ ' . $host . ' — connected';
            return array($pdo, $s['DB_NAME']);
        } catch (PDOException $e) {
            $why[] = $s['DB_NAME'] . ' @ ' . $host . ' — ' . $e->getMessage();
        }
    }
    return array(null, null);
}

/* ---------- choto helper gulo ---------- */
function cpps_has_table($pdo, $t)
{
    try {
        $st = $pdo->prepare('SELECT 1 FROM information_schema.TABLES
                              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $st->execute(array($t));
        return (bool) $st->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

function cpps_has_column($pdo, $t, $c)
{
    try {
        $st = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS
                              WHERE TABLE_SCHEMA = DATABASE()
                                AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $st->execute(array($t, $c));
        return (bool) $st->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

function cpps_has_index($pdo, $t, $k)
{
    try {
        $st = $pdo->prepare('SELECT 1 FROM information_schema.STATISTICS
                              WHERE TABLE_SCHEMA = DATABASE()
                                AND TABLE_NAME = ? AND INDEX_NAME = ?');
        $st->execute(array($t, $k));
        return (bool) $st->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

/** "already there" type error gulo — egulo bhul na. */
function cpps_benign(PDOException $e)
{
    $code = isset($e->errorInfo[1]) ? (int) $e->errorInfo[1] : 0;
    return in_array($code, array(1050, 1060, 1061, 1062, 1022, 1826, 1091, 1553), true);
}

/* ===================================================================
 * MIGRATION STEP GULO
 * =================================================================== */
function cpps_steps()
{
    return array(

        /* ---------- 1. VISITOR ANALYTICS ---------- */
        array(
            'name' => 'visits — page view log',
            'test' => array('table', 'visits'),
            'sql'  => "CREATE TABLE IF NOT EXISTS `visits` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `visitor_key`   CHAR(40)     NOT NULL,
  `user_id`       INT UNSIGNED DEFAULT NULL,
  `ip_address`    VARCHAR(45)  DEFAULT NULL,
  `page`          VARCHAR(190) NOT NULL DEFAULT '/',
  `page_title`    VARCHAR(160) DEFAULT NULL,
  `referrer`      VARCHAR(190) DEFAULT NULL,
  `referrer_host` VARCHAR(120) DEFAULT NULL,
  `country_code`  CHAR(2)      DEFAULT NULL,
  `country`       VARCHAR(80)  DEFAULT NULL,
  `region`        VARCHAR(80)  DEFAULT NULL,
  `city`          VARCHAR(80)  DEFAULT NULL,
  `device`        ENUM('desktop','mobile','tablet','bot','other') NOT NULL DEFAULT 'other',
  `browser`       VARCHAR(40)  DEFAULT NULL,
  `os`            VARCHAR(40)  DEFAULT NULL,
  `is_new`        TINYINT(1)   NOT NULL DEFAULT 0,
  `geo_state`     ENUM('pending','done','skipped') NOT NULL DEFAULT 'pending',
  `visit_date`    DATE         NOT NULL,
  `visit_hour`    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_visit_date`    (`visit_date`),
  KEY `idx_visit_country` (`country_code`,`visit_date`),
  KEY `idx_visit_key`     (`visitor_key`,`visit_date`),
  KEY `idx_visit_page`    (`page`,`visit_date`),
  KEY `idx_visit_user`    (`user_id`),
  KEY `idx_visit_geo`     (`geo_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        ),

        array(
            'name' => 'ip_geo — IP theke location cache',
            'test' => array('table', 'ip_geo'),
            'sql'  => "CREATE TABLE IF NOT EXISTS `ip_geo` (
  `ip`           VARCHAR(45)  NOT NULL,
  `country_code` CHAR(2)      DEFAULT NULL,
  `country`      VARCHAR(80)  DEFAULT NULL,
  `region`       VARCHAR(80)  DEFAULT NULL,
  `city`         VARCHAR(80)  DEFAULT NULL,
  `isp`          VARCHAR(120) DEFAULT NULL,
  `source`       VARCHAR(24)  NOT NULL DEFAULT 'api',
  `looked_up_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ip`),
  KEY `idx_geo_country` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        ),

        array(
            'name' => 'visit_daily — dinik roll-up',
            'test' => array('table', 'visit_daily'),
            'sql'  => "CREATE TABLE IF NOT EXISTS `visit_daily` (
  `visit_date`   DATE         NOT NULL,
  `country_code` CHAR(2)      NOT NULL DEFAULT '--',
  `views`        INT UNSIGNED NOT NULL DEFAULT 0,
  `visitors`     INT UNSIGNED NOT NULL DEFAULT 0,
  `members`      INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`visit_date`,`country_code`),
  KEY `idx_vd_country` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        ),

        /* ---------- 2. SPIN LIMIT ---------- */
        array(
            'name'    => 'spin_access.cooldown_minutes',
            'test'    => array('column', 'spin_access', 'cooldown_minutes'),
            'needs'   => 'spin_access',
            'sql'     => "ALTER TABLE `spin_access`
                          ADD COLUMN `cooldown_minutes` INT UNSIGNED DEFAULT NULL AFTER `bonus_spins`",
        ),
        array(
            'name'    => 'spin_access.weekly_cap',
            'test'    => array('column', 'spin_access', 'weekly_cap'),
            'needs'   => 'spin_access',
            'sql'     => "ALTER TABLE `spin_access`
                          ADD COLUMN `weekly_cap` INT UNSIGNED DEFAULT NULL AFTER `cooldown_minutes`",
        ),
        array(
            'name'    => 'spin_access.monthly_cap',
            'test'    => array('column', 'spin_access', 'monthly_cap'),
            'needs'   => 'spin_access',
            'sql'     => "ALTER TABLE `spin_access`
                          ADD COLUMN `monthly_cap` INT UNSIGNED DEFAULT NULL AFTER `weekly_cap`",
        ),
        array(
            'name'    => 'spin_results — cooldown-er jonno index',
            'test'    => array('index', 'spin_results', 'idx_spin_user_time'),
            'needs'   => 'spin_results',
            'sql'     => "ALTER TABLE `spin_results`
                          ADD KEY `idx_spin_user_time` (`user_id`,`created_at`)",
        ),
        array(
            // Purono "ek dine ekta-i spin" unique key ta thakle per-day
            // limit 1-er beshi kora jay na — 2nd insert duplicate hoye jay.
            'name'    => 'spin_results — purono uq_spin_day key sorano',
            'needs'   => 'spin_results',
            'drop_if' => array('spin_results', 'uq_spin_day'),
            'sql'     => "ALTER TABLE `spin_results` DROP INDEX `uq_spin_day`",
        ),
        array(
            'name'    => 'spin_results — idx_spin_day',
            'test'    => array('index', 'spin_results', 'idx_spin_day'),
            'needs'   => 'spin_results',
            'sql'     => "ALTER TABLE `spin_results` ADD KEY `idx_spin_day` (`user_id`,`spin_date`)",
        ),

        /* ---------- 3. GOVT EXAM ---------- */
        array(
            'name' => 'exam_notify — govt exam interest list',
            'test' => array('table', 'exam_notify'),
            'sql'  => "CREATE TABLE IF NOT EXISTS `exam_notify` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED DEFAULT NULL,
  `name`       VARCHAR(100) DEFAULT NULL,
  `email`      VARCHAR(150) NOT NULL,
  `phone`      VARCHAR(24)  DEFAULT NULL,
  `exam_pref`  VARCHAR(80)  DEFAULT NULL,
  `note`       VARCHAR(190) DEFAULT NULL,
  `ip_address` VARCHAR(45)  DEFAULT NULL,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exam_email` (`email`),
  KEY `idx_exam_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        ),

        array(
            'name'  => 'modules — govt_exam + analytics row',
            'needs' => 'modules',
            'sql'   => "INSERT IGNORE INTO `modules`
                          (`mkey`,`label`,`icon`,`blurb`,`kind`,`is_active`,`nav_visible`,`sort_order`)
                        VALUES
                          ('govt_exam','Govt Exam','&#127891;',
                           'Government competitive exam — coming-soon mode.','feature',1,1,25),
                          ('analytics','Visitor analytics','&#128200;',
                           'Page-view logging with country, region and city.','feature',1,0,80)",
        ),

        /* ---------- 4. SETTINGS ---------- */
        array(
            'name'  => 'settings — spin limit + analytics + exam',
            'needs' => 'settings',
            'sql'   => "INSERT IGNORE INTO `settings` (`skey`,`svalue`,`sgroup`,`slabel`) VALUES
  ('spin_default_per_day',    '1',    'spin',      'Spins per player per day'),
  ('spin_cooldown_minutes',   '0',    'spin',      'Minutes between two spins (0 = none)'),
  ('spin_weekly_cap',         '0',    'spin',      'Spins per player per week (0 = no cap)'),
  ('spin_monthly_cap',        '0',    'spin',      'Spins per player per month (0 = no cap)'),
  ('spin_limit_note',         '',     'spin',      'Extra line shown on the spin page'),
  ('analytics_enabled',       '1',    'analytics', 'Log visitors'),
  ('analytics_geo_mode',      'auto', 'analytics', 'off | header | auto'),
  ('analytics_ignore_admin',  '1',    'analytics', 'Skip views made by a signed-in admin'),
  ('analytics_ignore_bots',   '1',    'analytics', 'Skip crawlers'),
  ('analytics_retention_days','365',  'analytics', 'Keep raw page views for (days)'),
  ('analytics_salt',          '',     'analytics', 'Random salt for the visitor hash'),
  ('govt_exam_enabled',       '1',    'exam',      'Show Govt Exam in the navigation'),
  ('govt_exam_status',        'soon', 'exam',      'soon | live'),
  ('govt_exam_label',         'Govt Exam', 'exam', 'Navigation label'),
  ('govt_exam_launch',        '',     'exam',      'Launch date (YYYY-MM-DD)'),
  ('govt_exam_tagline',
   'WBCS, SSC, Rail, Bank & PSC practice — built the Asviora way.', 'exam', 'Landing tagline'),
  ('govt_exam_blurb',
   'Full-length mock tests, previous-year papers, sectional practice and a level ladder that actually tracks what you are weak at. Join the list and you will be the first in.',
   'exam', 'Landing paragraph')",
        ),
    );
}

/* ===================================================================
 * RUN
 * =================================================================== */
$sets   = cpps_creds($ROOT . '/config/config.php');
$why    = array();
$pdo    = null;
$dbName = null;
$report = array();
$before = null;
$after  = null;

if ($sets) {
    list($pdo, $dbName) = cpps_connect($sets, $why);
}

if ($pdo && $run) {
    try {
        $st = $pdo->prepare('SELECT svalue FROM settings WHERE skey = ?');
        $st->execute(array('schema_version'));
        $before = $st->fetchColumn();
    } catch (Exception $e) {
        $before = null;
    }

    foreach (cpps_steps() as $step) {
        $name = $step['name'];

        // je table-er upor kaj, seta na thakle skip
        if (isset($step['needs']) && !cpps_has_table($pdo, $step['needs'])) {
            $report[] = array($name, 'skip',
                              'table `' . $step['needs'] . '` nei — age agher migration chalan');
            continue;
        }

        // ekta index/key sorano — na thakle kichu korar nei
        if (isset($step['drop_if'])) {
            $d = $step['drop_if'];
            if (!cpps_has_index($pdo, $d[0], $d[1])) {
                $report[] = array($name, 'ok', 'agei sorano chilo');
                continue;
            }
        }

        // already ache kina
        if (isset($step['test'])) {
            $t = $step['test'];
            $exists = false;
            if ($t[0] === 'table')  { $exists = cpps_has_table($pdo, $t[1]); }
            if ($t[0] === 'column') { $exists = cpps_has_column($pdo, $t[1], $t[2]); }
            if ($t[0] === 'index')  { $exists = cpps_has_index($pdo, $t[1], $t[2]); }
            if ($exists) {
                $report[] = array($name, 'ok', 'agei chilo');
                continue;
            }
        }

        try {
            $pdo->exec($step['sql']);
            $report[] = array($name, 'done', 'toiri holo');
        } catch (PDOException $e) {
            if (cpps_benign($e)) {
                $report[] = array($name, 'ok', 'agei chilo');
            } else {
                $report[] = array($name, 'fail', $e->getMessage());
            }
        }
    }

    // analytics salt — ekbar-i toiri hobe
    try {
        $st = $pdo->prepare('SELECT svalue FROM settings WHERE skey = ?');
        $st->execute(array('analytics_salt'));
        $salt = (string) $st->fetchColumn();
        if ($salt === '') {
            $new = bin2hex(function_exists('random_bytes')
                           ? random_bytes(16) : pack('N4', mt_rand(), mt_rand(), mt_rand(), mt_rand()));
            $pdo->prepare('INSERT INTO settings (skey, svalue) VALUES (?, ?)
                           ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)')
                ->execute(array('analytics_salt', $new));
            $report[] = array('analytics_salt', 'done', 'notun salt toiri holo');
        } else {
            $report[] = array('analytics_salt', 'ok', 'agei chilo');
        }
    } catch (Exception $e) {
        $report[] = array('analytics_salt', 'fail', $e->getMessage());
    }

    // kono step fail na hole schema_version tule debo
    $failed = false;
    foreach ($report as $r) {
        if ($r[1] === 'fail') { $failed = true; }
    }

    if (!$failed) {
        try {
            $pdo->prepare('INSERT INTO settings (skey, svalue) VALUES (?, ?)
                           ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)')
                ->execute(array('schema_version', (string) $TARGET_VERSION));
            $after = $TARGET_VERSION;
            $report[] = array('schema_version', 'done', 'ekhon ' . $TARGET_VERSION);
        } catch (Exception $e) {
            $report[] = array('schema_version', 'fail', $e->getMessage());
        }
    } else {
        $report[] = array('schema_version', 'skip',
                          'upore kichu fail koreche — version bump kora holo na');
    }
}

/* ---------- ekhon ki obostha ---------- */
$state = array();
if ($pdo) {
    $state = array(
        'Database'                     => $dbName,
        'visits table'                 => cpps_has_table($pdo, 'visits') ? 'ache' : 'NEI',
        'ip_geo table'                 => cpps_has_table($pdo, 'ip_geo') ? 'ache' : 'NEI',
        'visit_daily table'            => cpps_has_table($pdo, 'visit_daily') ? 'ache' : 'NEI',
        'exam_notify table'            => cpps_has_table($pdo, 'exam_notify') ? 'ache' : 'NEI',
        'spin_access.cooldown_minutes' => cpps_has_column($pdo, 'spin_access', 'cooldown_minutes') ? 'ache' : 'NEI',
        'spin_access.weekly_cap'       => cpps_has_column($pdo, 'spin_access', 'weekly_cap') ? 'ache' : 'NEI',
        'spin_access.monthly_cap'      => cpps_has_column($pdo, 'spin_access', 'monthly_cap') ? 'ache' : 'NEI',
    );
    try {
        $st = $pdo->prepare('SELECT svalue FROM settings WHERE skey = ?');
        $st->execute(array('schema_version'));
        $state['schema_version'] = (string) $st->fetchColumn();
    } catch (Exception $e) {
        $state['schema_version'] = '?';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CPPS Migration — Asviora Games v6</title>
<style>
  :root{--bg:#0b0c0e;--card:#13161b;--line:#242a33;--txt:#e9eefc;--dim:#8b94a4;
        --green:#8fce3f;--gold:#d9a63c;--red:#ff7a7a}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--txt);
       font:15px/1.65 system-ui,-apple-system,"Segoe UI",sans-serif;padding:28px 16px}
  .wrap{max-width:900px;margin:0 auto}
  h1{font-size:1.5rem;margin:0 0 4px;color:var(--green)}
  h2{font-size:1.05rem;margin:26px 0 10px}
  p.sub{color:var(--dim);margin:0 0 22px}
  .card{background:var(--card);border:1px solid var(--line);border-radius:14px;
        padding:18px 20px;margin-bottom:18px}
  table{width:100%;border-collapse:collapse;font-size:14px}
  th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
  th{color:var(--dim);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.05em}
  code{background:#0e1116;border:1px solid var(--line);border-radius:6px;padding:1px 6px;font-size:13px}
  .pill{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:800;
        text-transform:uppercase;letter-spacing:.05em}
  .p-done{background:rgba(143,206,63,.18);color:var(--green)}
  .p-ok{background:rgba(139,148,164,.18);color:var(--dim)}
  .p-skip{background:rgba(217,166,60,.18);color:var(--gold)}
  .p-fail{background:rgba(255,122,122,.18);color:var(--red)}
  .btn{display:inline-block;padding:11px 20px;border-radius:10px;text-decoration:none;
       font-weight:800;background:linear-gradient(135deg,#8fce3f,#6aa521);color:#0b0c0e}
  .btn.ghost{background:transparent;border:1px solid var(--line);color:var(--txt)}
  .warn{background:rgba(217,166,60,.1);border:1px solid rgba(217,166,60,.4);
        border-radius:12px;padding:14px 16px;color:var(--gold);margin-bottom:18px}
  .bad{background:rgba(255,122,122,.1);border:1px solid rgba(255,122,122,.4);
       border-radius:12px;padding:14px 16px;color:var(--red);margin-bottom:18px}
  .good{background:rgba(143,206,63,.1);border:1px solid rgba(143,206,63,.4);
        border-radius:12px;padding:14px 16px;color:var(--green);margin-bottom:18px}
</style>
</head>
<body>
<div class="wrap">

  <h1>CPPS Migration — Asviora Games v6</h1>
  <p class="sub">Visitor analytics &middot; Spin limits &middot; Govt Exam module</p>

  <?php if (!$keyOk): ?>
    <div class="bad">
      <strong>Key lagbe.</strong> URL-e <code>?key=<?= htmlspecialchars($MIGRATION_KEY) ?></code>
      jog korun. Udahoron:<br>
      <code><?= htmlspecialchars((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
              . '://' . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'asviora.in')
              . (isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/cppsmigration.php')
              . '?key=' . $MIGRATION_KEY) ?></code>
    </div>
  <?php endif; ?>

  <div class="card">
    <h2 style="margin-top:0">Server</h2>
    <table>
      <?php foreach ($diag as $k => $v): ?>
        <tr><th style="width:230px"><?= htmlspecialchars($k) ?></th>
            <td><?= htmlspecialchars((string) $v) ?></td></tr>
      <?php endforeach; ?>
    </table>
  </div>

  <?php if ($keyOk): ?>

    <div class="card">
      <h2 style="margin-top:0">Database</h2>
      <?php if (!$sets): ?>
        <div class="bad"><code>config/config.php</code> theke DB credentials pawa gelo na.
          File ta ki thik jaygay ache?</div>
      <?php elseif (!$pdo): ?>
        <div class="bad">Kono set diyei connect kora gelo na:
          <ul><?php foreach ($why as $w): ?><li><?= htmlspecialchars($w) ?></li><?php endforeach; ?></ul>
        </div>
      <?php else: ?>
        <table>
          <?php foreach ($state as $k => $v): ?>
            <tr><th style="width:260px"><?= htmlspecialchars($k) ?></th>
                <td style="color:<?= $v === 'NEI' ? 'var(--red)' : 'inherit' ?>">
                  <?= htmlspecialchars((string) $v) ?></td></tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>

    <?php if ($pdo && !$run): ?>
      <div class="warn">
        <strong>Chalanor age:</strong> database-er ekta backup niye nin
        (hPanel &rarr; phpMyAdmin &rarr; Export). Migration ta idempotent —
        dubar chalale kichu nosto hoy na — kintu backup thaka bhalo.
      </div>
      <p>
        <a class="btn" href="?key=<?= urlencode($MIGRATION_KEY) ?>&amp;run=1">
          Migration chalao &rarr;</a>
      </p>
    <?php endif; ?>

    <?php if ($report): ?>
      <?php
      $nFail = 0; $nDone = 0;
      foreach ($report as $r) {
          if ($r[1] === 'fail') { $nFail++; }
          if ($r[1] === 'done') { $nDone++; }
      }
      ?>
      <?php if ($nFail === 0): ?>
        <div class="good"><strong>Sob thik ache.</strong>
          <?= (int) $nDone ?> ta poriborton apply holo, baki gulo agei chilo.
          Ekhon admin panel-e <code>Visitors</code>, <code>Govt Exam</code> ar
          <code>Daily Spin &rarr; Spin limits</code> dekhte paben.
          <br><br><strong>Ei file ta ekhon server theke delete kore din.</strong>
        </div>
      <?php else: ?>
        <div class="bad"><strong><?= (int) $nFail ?> ta step fail koreche.</strong>
          Niche error ta dekhun. Thik kore abar chalate paren — jetuku hoye geche
          seta abar hobe na.</div>
      <?php endif; ?>

      <div class="card">
        <h2 style="margin-top:0">Ki holo</h2>
        <table>
          <thead><tr><th>Step</th><th style="width:90px">Result</th><th>Details</th></tr></thead>
          <tbody>
            <?php foreach ($report as $r): ?>
              <tr>
                <td><?= htmlspecialchars($r[0]) ?></td>
                <td><span class="pill p-<?= htmlspecialchars($r[1]) ?>">
                  <?= htmlspecialchars($r[1]) ?></span></td>
                <td style="color:var(--dim)"><?= htmlspecialchars($r[2]) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <p style="color:var(--dim);margin:14px 0 0">
          schema_version: <code><?= htmlspecialchars((string) ($before === null ? '?' : $before)) ?></code>
          &rarr; <code><?= htmlspecialchars((string) ($after === null ? ($before === null ? '?' : $before) : $after)) ?></code>
        </p>
      </div>

      <p>
        <a class="btn ghost" href="admin/visitors.php">Admin &rarr; Visitors</a>
        <a class="btn ghost" href="admin/spin.php">Admin &rarr; Daily Spin</a>
        <a class="btn ghost" href="admin/govt-exam.php">Admin &rarr; Govt Exam</a>
      </p>
    <?php endif; ?>

  <?php endif; ?>

  <p style="color:var(--dim);font-size:13px;margin-top:30px">
    Asviora Games &middot; cppsmigration.php &middot; target schema v<?= (int) $TARGET_VERSION ?>
  </p>
</div>
</body>
</html>

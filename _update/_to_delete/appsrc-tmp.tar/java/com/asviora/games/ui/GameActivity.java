package com.asviora.games.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.asviora.games.R;
import com.asviora.games.net.Api;

import org.json.JSONObject;

/**
 * Plays one of the HTML5 games.
 *
 * The games themselves — chess, sudoku, memory, the cube — are canvas and
 * WebGL, so they run in a controlled WebView rather than being rewritten
 * twice. Everything else in the app is native: this screen exists only for
 * the game surface, and it is locked down to the site's own origin.
 *
 * Since the site put every playable page behind a login, the plain game URL
 * would bounce this WebView to login.php — it has a bearer token, not a
 * cookie. So the screen is never opened with a URL from the catalogue any
 * more: {@link #open} asks the API for a short-lived signed ticket first and
 * opens the URL that comes back, which the server turns into a session for
 * this WebView. Cookies therefore have to be on.
 */
public class GameActivity extends AppCompatActivity {

    public static final String EXTRA_URL   = "url";
    public static final String EXTRA_TITLE = "title";

    private WebView web;

    /**
     * The only way in. Fetches a play ticket, then opens the board.
     *
     * The ticket names one game, dies in fifteen minutes and is signed by
     * the server, so nothing worth stealing travels in the URL — the bearer
     * token itself never leaves the Authorization header.
     */
    public static void open(final Context ctx, final String slug, final String title) {
        Api.get("games/ticket?game=" + Uri.encode(slug), new Api.Callback() {
            @Override public void onSuccess(JSONObject data) {
                String url = data.optString("play_url", "");
                if (url.isEmpty()) {
                    Toast.makeText(ctx, "That game could not be opened.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent it = new Intent(ctx, GameActivity.class);
                it.putExtra(EXTRA_URL, url);
                it.putExtra(EXTRA_TITLE, title);
                ctx.startActivity(it);
            }

            @Override public void onError(String code, String message) {
                Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_game);

        String url   = getIntent().getStringExtra(EXTRA_URL);
        String title = getIntent().getStringExtra(EXTRA_TITLE);
        setTitle(title == null ? "" : title);

        web = findViewById(R.id.web);

        // The play ticket is exchanged for a session cookie by the server,
        // and every asset the game asks for afterwards rides on it.
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);            // the games are JavaScript
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        final String host = android.net.Uri.parse(
                com.asviora.games.BuildConfig.SITE_BASE).getHost();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req) {
                // never let a game navigate the WebView somewhere else
                String h = req.getUrl().getHost();
                return h == null || host == null || !h.equalsIgnoreCase(host);
            }
        });

        if (url != null) web.loadUrl(url);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.loadUrl("about:blank");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}

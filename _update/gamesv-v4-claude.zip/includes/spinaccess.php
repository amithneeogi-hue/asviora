<?php
/**
 * Who is allowed to spin the wheel, and how often.
 *
 * Two modes, set in Admin -> Site Settings (or Admin -> Spin Access):
 *
 *   all       every signed-in player gets the default number of spins a day
 *   assigned  only players the admin has granted access can spin at all
 *
 * On top of that, each player can carry a personal allowance (more spins a
 * day than everyone else), one-off bonus spins, and a validity window.
 */

/** 'all' or 'assigned'. */
function spin_access_mode(): string
{
    return setting('spin_access_mode', 'all') === 'assigned' ? 'assigned' : 'all';
}

/** Default spins per day for players with no personal row. */
function spin_default_per_day(): int
{
    return max(0, (int) setting('spin_default_per_day', '1'));
}

/** The player's access row, or null if they have never been given one. */
function spin_access_row(int $userId): ?array
{
    if (!has_table('spin_access')) {
        return null;
    }
    return fetch_one('SELECT * FROM spin_access WHERE user_id = ?', [$userId]);
}

/** How many spins the player has already used today. */
function spin_used_today(int $userId): int
{
    if (!has_table('spin_results')) {
        return 0;
    }
    return (int) fetch_col(
        'SELECT COUNT(*) FROM spin_results WHERE user_id = ? AND spin_date = CURDATE()',
        [$userId], 0
    );
}

/**
 * The whole picture for one player.
 *
 * ['allowed' => bool, 'reason' => string, 'per_day' => int, 'used' => int,
 *  'bonus' => int, 'remaining' => int, 'granted' => bool]
 */
function spin_status(int $userId): array
{
    $row     = spin_access_row($userId);
    $mode    = spin_access_mode();
    $today   = date('Y-m-d');
    $granted = $row !== null;

    $out = [
        'allowed'   => true,
        'reason'    => '',
        'per_day'   => spin_default_per_day(),
        'used'      => spin_used_today($userId),
        'bonus'     => 0,
        'remaining' => 0,
        'granted'   => $granted,
        'mode'      => $mode,
        'note'      => $row['note'] ?? '',
    ];

    // --- assigned mode: no row, no spin ---------------------------------
    if ($mode === 'assigned' && !$granted) {
        $out['allowed'] = false;
        $out['reason']  = 'The wheel is invitation-only right now. An admin has to switch it on for your account.';
        return $out;
    }

    if ($granted) {
        if ((int) $row['is_allowed'] !== 1) {
            $out['allowed'] = false;
            $out['reason']  = 'Spin access is switched off for your account.';
            return $out;
        }
        if (!empty($row['valid_from']) && $row['valid_from'] > $today) {
            $out['allowed'] = false;
            $out['reason']  = 'Your spin access starts on ' . fdate($row['valid_from']) . '.';
            return $out;
        }
        if (!empty($row['valid_until']) && $row['valid_until'] < $today) {
            $out['allowed'] = false;
            $out['reason']  = 'Your spin access ended on ' . fdate($row['valid_until']) . '.';
            return $out;
        }

        $out['per_day'] = max(0, (int) $row['spins_per_day']);
        $out['bonus']   = max(0, (int) $row['bonus_spins']);
    }

    $out['remaining'] = max(0, $out['per_day'] - $out['used']) + $out['bonus'];

    if ($out['remaining'] <= 0) {
        $out['allowed'] = false;
        $out['reason']  = $out['per_day'] > 0
            ? 'You have used all ' . $out['per_day'] . ' of today\'s spins. Come back tomorrow.'
            : 'No spins are allocated to your account.';
    }

    return $out;
}

/** Shorthand: may this player spin right now? */
function spin_can(int $userId): bool
{
    return spin_status($userId)['allowed'];
}

/**
 * Book one spin. Call this straight after a spin is recorded so that a
 * bonus spin is burnt rather than the daily allowance, when one is due.
 */
function spin_consume(int $userId): void
{
    if (!has_table('spin_access')) {
        return;
    }

    $row = spin_access_row($userId);
    if (!$row || (int) $row['bonus_spins'] <= 0) {
        return;
    }

    // the daily allowance is counted from spin_results; a bonus spin is
    // only burnt once that allowance is already spent
    $used = spin_used_today($userId);          // includes the spin just taken
    if ($used > max(0, (int) $row['spins_per_day'])) {
        q('UPDATE spin_access SET bonus_spins = GREATEST(bonus_spins - 1, 0) WHERE user_id = ?',
          [$userId]);
    }
}

/** Create or update a player's access row. */
function spin_access_set(int $userId, array $data, ?int $adminId = null): void
{
    if (!has_table('spin_access')) {
        return;
    }

    $fields = [
        'is_allowed'    => isset($data['is_allowed']) ? (int) (bool) $data['is_allowed'] : 1,
        'spins_per_day' => max(0, (int) ($data['spins_per_day'] ?? spin_default_per_day())),
        'bonus_spins'   => max(0, (int) ($data['bonus_spins'] ?? 0)),
        'valid_from'    => $data['valid_from'] ?: null,
        'valid_until'   => $data['valid_until'] ?: null,
        'note'          => mb_substr((string) ($data['note'] ?? ''), 0, 190) ?: null,
        'granted_by'    => $adminId,
    ];

    if (spin_access_row($userId)) {
        update_row('spin_access', $fields, 'user_id = ?', [$userId]);
    } else {
        $fields['user_id'] = $userId;
        insert_row('spin_access', $fields);
    }
}

/** Remove a player's personal row — they fall back to the site default. */
function spin_access_clear(int $userId): void
{
    if (has_table('spin_access')) {
        q('DELETE FROM spin_access WHERE user_id = ?', [$userId]);
    }
}
